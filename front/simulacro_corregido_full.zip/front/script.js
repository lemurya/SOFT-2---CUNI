
let usuario = null;

function registrar() {
  const nombre = document.getElementById("nombreRegistro").value;
  const correo = document.getElementById("correoRegistro").value;
  const contrasena = document.getElementById("contrasenaRegistro").value;

  fetch("http://localhost:3000/api/usuarios/registro", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ nombre, correo, contrasena })
  })
    .then(res => res.json())
    .then(data => alert(data.mensaje));
}

function login() {
  const correo = document.getElementById("correo").value;
  const contrasena = document.getElementById("contrasena").value;

  fetch("http://localhost:3000/api/usuarios/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ correo, contrasena })
  })
    .then(res => res.json())
    .then(data => {
      usuario = data.datos;
      document.getElementById("usuarioInfo").style.display = "block";
      document.getElementById("usuarioNombre").innerText = usuario.nombre;
      document.getElementById("usuarioExp").innerText = usuario.experiencia;
      document.getElementById("usuarioMonedas").innerText = usuario.monedas;
    });
}

function actualizarNombre() {
  const nuevoNombre = document.getElementById("nuevoNombre").value;

  fetch("http://localhost:3000/api/usuarios/cambiar-nombre", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ correo: usuario.correo, nuevoNombre })
  })
    .then(res => res.json())
    .then(data => {
      alert(data.mensaje);
      usuario.nombre = nuevoNombre;
      document.getElementById("usuarioNombre").innerText = nuevoNombre;
    });
}

// Resto de funciones omitidas por espacio: iniciarSimulacro, responder, verResultados, verReportes, verReportesPorTema
