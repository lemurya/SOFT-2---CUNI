
const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const userRoutes = require('./routes/UserRoutes');
app.use('/api/usuarios', userRoutes);

const publicPath = path.join(__dirname, 'front');
app.use(express.static(publicPath));

app.get('/', (req, res) => {
  res.redirect('/index.html');
});

app.listen(PORT, () => {
  console.log(`✅ Servidor escuchando en: http://localhost:${PORT}`);
});
