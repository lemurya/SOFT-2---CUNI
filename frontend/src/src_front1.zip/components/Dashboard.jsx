import React, { useEffect, useState } from 'react';
import {
  Box, Typography, Paper
} from '@mui/material';

const Dashboard = () => {
  const [usuario, setUsuario] = useState(null);

  useEffect(() => {
    const datos = JSON.parse(localStorage.getItem('usuario'));
    setUsuario(datos);
  }, []);

  if (!usuario) {
    return (
      <Box sx={{ p: 4 }}>
        <Typography variant="h6">Cargando usuario...</Typography>
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        bgcolor: '#e8f5e9'
      }}
    >
      <Paper sx={{ p: 4, minWidth: 400 }}>
        <Typography variant="h4" gutterBottom>
          ¡Bienvenido, {usuario.nombre}!
        </Typography>
        <Typography variant="body1">Correo: {usuario.correo}</Typography>
        <Typography variant="body1">Experiencia: {usuario.experiencia}</Typography>
        <Typography variant="body1">Monedas: {usuario.monedas}</Typography>
      </Paper>
    </Box>
  );
};

export default Dashboard;